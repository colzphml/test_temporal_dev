import asyncio
import os
import sys
import uuid

import httpx

BASE = os.environ.get("MOCKS_URL", "http://localhost:8100")


class BusinessError(Exception):
    def __init__(self, status_code, payload):
        self.status_code = status_code
        self.payload = payload


async def call(client: httpx.AsyncClient, method: str, path: str, json=None, headers=None):
    """Make API call with retry for transient errors (500, network/timeout).
    Business errors (400, 402, 404, 409, 422) are raised without retry."""
    delay = 0.5
    last_exc = None
    for attempt in range(1, 6):
        try:
            r = await client.request(method, BASE + path, json=json, headers=headers)
            if r.status_code < 400 or r.status_code == 201:
                return r.json()
            if r.status_code in (400, 402, 404, 409, 422):
                raise BusinessError(r.status_code, r.json())
            # 500 is transient - retry
        except (httpx.TransportError, BusinessError) as e:
            if isinstance(e, BusinessError):
                raise
            last_exc = e
        if attempt == 5:
            raise RuntimeError(f"{method} {path}: retries exhausted (last={last_exc})")
        await asyncio.sleep(delay)
        delay = min(delay * 2, 4)
    raise RuntimeError(f"{method} {path}: retries exhausted")


async def process_order(client: httpx.AsyncClient, order: dict):
    oid = order["order_id"]
    idempotency_key = f"pay-{oid}-{uuid.uuid4().hex[:8]}"
    final_status = "completed"
    reason = None

    # Step 1: Reserve inventory
    try:
        await call(client, "POST", "/api/inventory/reserve",
                   json={"order_id": oid, "items": order["items"]})
    except BusinessError as e:
        if e.status_code == 409:  # out_of_stock
            final_status = "cancelled"
            reason = "out_of_stock"
            await notify(client, oid, final_status, reason)
            return
        raise

    # Step 2: Charge payment
    try:
        await call(client, "POST", "/api/payments/charge",
                   json={"order_id": oid, "amount": order["amount"]},
                   headers={"Idempotency-Key": idempotency_key})
    except BusinessError as e:
        if e.status_code == 402:  # card_declined
            # Compensate: release inventory
            await call(client, "POST", "/api/inventory/release",
                       json={"order_id": oid})
            final_status = "cancelled"
            reason = "payment_declined"
            await notify(client, oid, final_status, reason)
            return
        raise

    # Step 3: Create shipment
    shipment_resp = await call(client, "POST", "/api/shipping/shipments",
                               json={"order_id": oid})
    shipment_id = shipment_resp["shipment_id"]

    # Step 4: Poll shipment until terminal
    while True:
        st_resp = await call(client, "GET", f"/api/shipping/shipments/{shipment_id}")
        status = st_resp["status"]
        if status == "delivered":
            final_status = "completed"
            reason = None
            break
        if status == "failed":
            # Compensate: refund payment AND release inventory (either order)
            await asyncio.gather(
                call(client, "POST", "/api/payments/refund", json={"order_id": oid}),
                call(client, "POST", "/api/inventory/release", json={"order_id": oid}),
            )
            final_status = "cancelled"
            reason = "shipping_failed"
            break
        await asyncio.sleep(1)

    await notify(client, oid, final_status, reason)


async def notify(client: httpx.AsyncClient, order_id: str, status: str, reason: str | None):
    await call(client, "POST", "/api/notifications/notify",
               json={"order_id": order_id, "status": status, "reason": reason})


async def main():
    async with httpx.AsyncClient(timeout=30, trust_env=False) as client:
        r = await client.get(f"{BASE}/api/orders")
        orders = r.json()
        print(f"Fetched {len(orders)} orders")
        results = await asyncio.gather(
            *(process_order(client, o) for o in orders),
            return_exceptions=True,
        )
        failures = [(o["order_id"], e) for o, e in zip(orders, results)
                    if isinstance(e, Exception)]
        if failures:
            for oid, exc in failures:
                print(f"FAIL {oid}: {exc}", file=sys.stderr)
            sys.exit(1)
        print("All orders processed successfully")


if __name__ == "__main__":
    asyncio.run(main())
