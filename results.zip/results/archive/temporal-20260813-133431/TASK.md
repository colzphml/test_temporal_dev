# Задача: сервис обработки заказов интернет-магазина

Это рабочее задание. Выполняй его в текущей папке — твоём изолированном воркспейсе.

## Правила сессии (обязательные)

1. САМОЕ ПЕРВОЕ действие: выполни `make begin` — это фиксация времени старта.
   Команда идемпотентна, повторный запуск безвреден.
2. Работай только внутри текущей папки. Не читай и не изменяй файлы за её
   пределами (`../`, исходники моков, чекера, других вариантов).
3. Ничего не устанавливай: все зависимости уже стоят в `./.venv`. Запускай
   питон только оттуда: `./.venv/bin/python` (из папки solution — `../.venv/bin/python`).
4. Если в контексте есть общие инструкции про вики-память, таск-трекеры или
   MCP-инструменты — в этой сессии они ОТКЛЮЧЕНЫ, не используй их.
5. Готовность = команда `make verify` завершилась успехом (`✅ VERIFY PASSED`).
   Запускай её сколько угодно — она сама сбрасывает моки и прогоняет решение.
6. Решение живёт в папке `solution/`; точка входа — `solution/run.sh`
   (контракт — в конце спецификации).
7. Окружение уже поднято (docker compose): моки бизнес-сервисов на
   http://localhost:8100. Ничего поднимать не нужно.

Полезные команды воркспейса: `make verify`, `make state` (состояние заказов),
`make ledger ORDER=ORD-1001` (журнал вызовов), `make reset`.

Дальше — спецификация процесса и API, затем — вариант реализации. Прочитай всё,
потом реализуй.


---

# Спецификация: обработка заказов интернет-магазина

## 1. Легенда

Интернет-магазин обрабатывает оплаченные заказы. Вокруг — четыре бизнес-сервиса
(склад, платежи, доставка, уведомления), доступные по HTTP на `http://localhost:8100`
(адрес также передаётся в переменной окружения `MOCKS_URL`). Сервисы ненадёжны:
временами отвечают 500, бывают бизнес-отказы. Твоя задача — написать обработчик,
который проводит каждый заказ до терминального состояния, несмотря на сбои.

## 2. Входные данные

Список заказов отдаёт `GET /api/orders`:

```json
[
  {
    "order_id": "ORD-1001",
    "customer": "alice",
    "amount": 49.90,
    "currency": "EUR",
    "items": [{"sku": "BOOK-CLEAN-ARCH", "qty": 1}]
  }
]
```

Заказов 10. Каждый нужно обработать по алгоритму ниже. Какому заказу «повезёт»
со сбоями — заранее неизвестно: обработчик обязан быть универсальным, без
привязки к конкретным order_id.

## 3. Алгоритм обработки одного заказа

Шаги строго в этом порядке; уведомление — всегда последний шаг.

1. **Резерв на складе**: `POST /api/inventory/reserve` с `{order_id, items}`.
   - `409 out_of_stock` → заказ отменяется: перейти к шагу 6 со статусом
     `cancelled` (причина `out_of_stock`). Оплату НЕ вызывать.
2. **Оплата**: `POST /api/payments/charge` с `{order_id, amount}` и заголовком
   `Idempotency-Key` (см. раздел 5). `amount` — ровно из заказа.
   - `402 card_declined` → компенсация: снять резерв
     (`POST /api/inventory/release`), затем шаг 6 со статусом `cancelled`
     (причина `payment_declined`). 402 не ретраить — это окончательный отказ банка.
3. **Создание отправления**: `POST /api/shipping/shipments` с `{order_id}` →
   в ответе `shipment_id`.
4. **Ожидание доставки**: опрашивать `GET /api/shipping/shipments/{shipment_id}`
   раз в ~1 секунду, пока статус не станет терминальным:
   - `delivered` → шаг 6 со статусом `completed`;
   - `failed` → компенсация: вернуть деньги (`POST /api/payments/refund`
     с `{order_id}`) И снять резерв (`POST /api/inventory/release`), затем шаг 6
     со статусом `cancelled` (причина `shipping_failed`).
   Нетерминальные статусы: `preparing`, `shipped` — продолжать опрос.
5. (нет шага — зарезервировано)
6. **Финальное уведомление**: `POST /api/notifications/notify` с
   `{order_id, status, reason}`, где `status` — ровно `completed` или
   `cancelled` (других значений сервис не принимает), `reason` — произвольная
   строка или null. Уведомление обязательно при ЛЮБОМ исходе и идёт последним.

Таблица исходов:

| Ситуация | Финальный статус | Обязательные действия до уведомления |
|---|---|---|
| Доставлено (`delivered`) | `completed` | reserve → charge → shipment → дождаться `delivered` |
| Нет на складе (409 на reserve) | `cancelled` | ничего (оплату не вызывать) |
| Отказ банка (402 на charge) | `cancelled` | release |
| Доставка провалена (`failed`) | `cancelled` | refund И release (в любом порядке между собой) |

## 4. Ошибки и ретраи

| Ответ | Что значит | Что делать |
|---|---|---|
| `500` (любой сервис) | временный сбой | ретраить: до 5 попыток, экспоненциальный бэкофф от 0.5с (0.5, 1, 2, 4… максимум 4с между попытками) |
| сетевая ошибка / таймаут | временный сбой | так же, как 500 |
| `409 out_of_stock` (reserve) | бизнес-отказ | НЕ ретраить, ветка отмены |
| `402 card_declined` (charge) | бизнес-отказ | НЕ ретраить, ветка компенсации |
| `404`, `400`, `422` | ошибка в твоём запросе | НЕ ретраить, чинить код |

Ретраи нужны на КАЖДОМ шаге, включая финальное уведомление: сервис уведомлений
тоже может отвечать 500 несколько раз подряд.

## 5. Идемпотентность оплаты

У платёжного сервиса бывает сбой, при котором списание УЖЕ записано, а ответ —
500. Поэтому:

- на каждый заказ сгенерируй ОДИН `Idempotency-Key` (любая уникальная строка,
  например `pay-<order_id>-<uuid>`);
- передавай его заголовком в каждой попытке `charge` этого заказа — при ретраях
  ключ ТОТ ЖЕ САМЫЙ, не генерируй новый;
- если списание уже прошло, сервис по знакомому ключу вернёт его же, без
  двойного списания.

Ретрай с новым ключом после такого сбоя = двойное списание = проверка провалена.

## 6. Параллельность и лимит времени

Заказы обрабатывай конкурентно, а не по одному. Проверяются два инварианта:

- **одновременность**: интервалы обработки заказов (от первого вызова API заказа
  до его финального уведомления) должны пересекаться — в пике не меньше **8 из
  10** заказов в работе одновременно. Практически это значит: запусти обработку
  всех заказов сразу (например, gather), а не циклом по одному.
- **лимит**: от первого вызова API до последнего финального уведомления —
  не больше **90 секунд**. При конкурентной обработке реальное время сильно
  меньше (самая долгая доставка ~15с).

## 7. Справочник API (моки на http://localhost:8100)

Все запросы и ответы — JSON. Во всех POST — заголовок `Content-Type: application/json`.

### Заказы
`GET /api/orders` → `200` список заказов (формат в разделе 2).

### Склад
`POST /api/inventory/reserve` — тело `{"order_id": "...", "items": [{"sku": "...", "qty": 1}]}`
- `200 {"reservation_id": "res_...", "status": "reserved"}` — успех (повторный
  вызов при живом резерве вернёт тот же резерв — безопасно ретраить);
- `409 {"error": "out_of_stock"}` — товара нет, резерв невозможен;
- `500 {"error": "internal_error"}` — временный сбой, ретраить.

`POST /api/inventory/release` — тело `{"order_id": "..."}`
- `200 {"status": "released" | "already_released" | "nothing_reserved"}` —
  идемпотентен, всегда успешен (кроме 500).

### Платежи
`POST /api/payments/charge` — тело `{"order_id": "...", "amount": 49.90}`,
заголовок `Idempotency-Key: <ключ>` (обязателен по разделу 5)
- `200 {"charge_id": "ch_...", "status": "succeeded"}` — успех (по знакомому
  ключу — то же списание, поле `idempotent_replay: true`);
- `402 {"error": "card_declined"}` — окончательный отказ банка, не ретраить;
- `500 {"error": "internal_error"}` — временный сбой; ретраить С ТЕМ ЖЕ ключом.

`POST /api/payments/refund` — тело `{"order_id": "..."}`
- `200 {"refund_id": "rf_...", "status": "refunded"}` — идемпотентен (повторный
  вызов вернёт тот же возврат);
- `404 {"error": "nothing_to_refund"}` — по заказу нет успешных списаний.

### Доставка
`POST /api/shipping/shipments` — тело `{"order_id": "..."}`
- `201 {"shipment_id": "shp_...", "status": "accepted"}` — создано (повторный
  вызов вернёт `200` с тем же shipment_id);
- `500` — временный сбой, ретраить.

`GET /api/shipping/shipments/{shipment_id}`
- `200 {"shipment_id": "...", "order_id": "...", "status": "preparing" | "shipped" | "delivered" | "failed"}`;
- `404` — неизвестный shipment_id.

### Уведомления
`POST /api/notifications/notify` — тело
`{"order_id": "...", "status": "completed" | "cancelled", "reason": "строка или null"}`
- `200 {"status": "accepted"}`;
- `422` — неверный статус (допустимы только `completed` и `cancelled`);
- `500` — временный сбой, ретраить.

### Отладка (не для бизнес-логики)
- `GET /admin/state` — сводка по всем заказам: попытки, резервы, списания, статусы.
- `GET /admin/ledger?order_id=ORD-1001` — журнал всех вызовов API.
- `POST /admin/reset` — полный сброс моков (`make verify` делает это сам перед прогоном).

## 8. Что проверяет `make verify`

Verify сбрасывает моки, запускает твоё `solution/run.sh` и проверяет журнал:

1. Каждый заказ дошёл до правильного терминального статуса и отправлено финальное
   уведомление ровно с тем статусом, что в таблице исходов.
2. Порядок шагов внутри заказа соблюдён (резерв → оплата → отправление →
   доставка → уведомление; уведомление — последним).
3. Ретраи выполнены там, где сервисы отвечали 500 (недостаточно попыток = провал).
4. Нет двойных списаний (идемпотентность), суммы совпадают с заказом.
5. Компенсации выполнены: release при отказе банка; refund + release при провале
   доставки. Нет лишних списаний/возвратов/отправлений по отменённым заказам.
6. Заказы обрабатывались конкурентно (в пике ≥ 8 одновременно), и весь прогон
   уложился в 90 секунд.
7. `run.sh` завершился сам с кодом 0 (жёсткий предел 150с, дольше — провал).

## 9. Контракт solution/run.sh

- Запускается как `bash run.sh` с рабочей директорией `solution/`.
- В окружении доступны `MOCKS_URL` (http://localhost:8100), `TEMPORAL_ADDRESS`
  (localhost:7233), `TEMPORAL_NAMESPACE` (default).
- Обрабатывает ВСЕ заказы из `GET /api/orders` до терминальных состояний и
  завершается с кодом 0; при невозможности завершить — ненулевой код.
- Убивает свои фоновые процессы при выходе (если они есть).
- Ничего не устанавливает; питон — только `../.venv/bin/python`.


---

# Вариант реализации: Temporal (Python SDK)

## Стек

- Temporal-сервер УЖЕ запущен: gRPC `localhost:7233` (есть в `TEMPORAL_ADDRESS`),
  namespace `default`, Web-UI: http://localhost:8233.
- Python из `./.venv` (стоят `temporalio==1.31.0` и `httpx==0.28.1`).
- Архитектура обязательна: каждый заказ — отдельный workflow; все HTTP-вызовы —
  в activities; ретраи — через RetryPolicy Temporal (не пиши свои циклы ретраев).

## Рекомендуемая структура

```
solution/
├── run.sh          # точка входа (контракт в SPEC, раздел 9)
├── activities.py   # HTTP-вызовы моков (httpx) — весь ввод-вывод здесь
├── workflows.py    # OrderWorkflow — чистая оркестрация, без httpx
├── worker.py       # регистрирует workflow + activities, слушает task queue
└── starter.py      # получает заказы, запускает workflow'ы, ждёт результаты
```

`run.sh` для этого варианта (worker в фоне, starter в форграунде):

```bash
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
../.venv/bin/python worker.py &
WORKER_PID=$!
trap 'kill $WORKER_PID 2>/dev/null || true; wait $WORKER_PID 2>/dev/null || true' EXIT
sleep 2   # дать worker'у подключиться
../.venv/bin/python starter.py
```

## Шпаргалка по стеку

`activities.py` — все вызовы HTTP; бизнес-ошибки помечай non_retryable:

```python
import os, httpx
from temporalio import activity
from temporalio.exceptions import ApplicationError

BASE = os.environ.get("MOCKS_URL", "http://localhost:8100")

async def _call(method, path, json=None, headers=None):
    # trust_env=False обязательно: иначе системный прокси macOS перехватит
    # запросы к localhost и они не дойдут до моков
    async with httpx.AsyncClient(timeout=10, trust_env=False) as client:
        r = await client.request(method, BASE + path, json=json, headers=headers)
    if r.status_code < 400:
        return r.json()
    if r.status_code in (400, 402, 404, 409, 422):
        # бизнес-ошибка: Temporal НЕ будет её ретраить (non_retryable),
        # workflow поймает её и уйдёт в ветку компенсации
        raise ApplicationError(f"HTTP {r.status_code}: {r.text}",
                               type=f"Business{r.status_code}", non_retryable=True)
    raise ApplicationError(f"HTTP {r.status_code}", type="ServerError")  # 5xx — ретраится политикой

@activity.defn
async def reserve_inventory(inp: dict) -> dict:
    return await _call("POST", "/api/inventory/reserve", json=inp)
# ... остальные activities аналогично, по одной на вызов API
```

`workflows.py` — оркестрация; httpx сюда импортировать НЕЛЬЗЯ (песочница
workflow запрещает недетерминированные импорты — заворачивай их так):

```python
from datetime import timedelta
from temporalio import workflow
from temporalio.common import RetryPolicy
from temporalio.exceptions import ActivityError

with workflow.unsafe.imports_passed_through():
    from activities import reserve_inventory, charge_payment  # и остальные

RETRY = RetryPolicy(
    initial_interval=timedelta(seconds=0.5),
    backoff_coefficient=2.0,
    maximum_interval=timedelta(seconds=4),
    maximum_attempts=5,
    non_retryable_error_types=["Business400", "Business402", "Business404",
                               "Business409", "Business422"],
)
OPTS = {"start_to_close_timeout": timedelta(seconds=10), "retry_policy": RETRY}

def business_type(err: ActivityError):
    """Тип бизнес-ошибки из упавшей activity ('Business402'...) или None."""
    cause = getattr(err, "cause", None)
    t = getattr(cause, "type", None) or ""
    return t if t.startswith("Business") else None

@workflow.defn
class OrderWorkflow:
    @workflow.run
    async def run(self, order: dict) -> str:
        oid = order["order_id"]
        try:
            await workflow.execute_activity(reserve_inventory,
                {"order_id": oid, "items": order["items"]}, **OPTS)
        except ActivityError as e:
            if business_type(e) != "Business409":
                raise
            # ... ветка отмены: notify cancelled, return
        key = f"pay-{oid}-{workflow.uuid4().hex[:8]}"   # детерминированный uuid — только так
        # ... charge с этим ключом; Business402 → release + notify cancelled
        # ... create_shipment; затем опрос:
        #     status = "preparing"
        #     while status not in ("delivered", "failed"):
        #         await workflow.sleep(1)               # durable-таймер вместо time.sleep
        #         status = await workflow.execute_activity(get_shipment_status, sid, **OPTS)
        # ... failed → refund + release + notify cancelled; delivered → notify completed
```

Важно: внутри workflow запрещены `time.sleep`, `uuid.uuid4()`, `random`,
`datetime.now()` — вместо них `workflow.sleep()`, `workflow.uuid4()`,
`workflow.now()`. В activities ограничений нет.

`worker.py`:

```python
import asyncio, os
from temporalio.client import Client
from temporalio.worker import Worker
import activities
from workflows import OrderWorkflow

async def main():
    client = await Client.connect(os.environ.get("TEMPORAL_ADDRESS", "localhost:7233"))
    worker = Worker(client, task_queue="orders",
                    workflows=[OrderWorkflow],
                    activities=[activities.reserve_inventory, ...])  # перечисли все
    print("worker запущен")
    await worker.run()

asyncio.run(main())
```

`starter.py` — конкурентный запуск всех заказов:

```python
import asyncio, os, sys, time, httpx
from temporalio.client import Client
from workflows import OrderWorkflow

async def main():
    base = os.environ.get("MOCKS_URL", "http://localhost:8100")
    async with httpx.AsyncClient(timeout=10, trust_env=False) as c:
        orders = (await c.get(base + "/api/orders")).json()
    client = await Client.connect(os.environ.get("TEMPORAL_ADDRESS", "localhost:7233"))
    stamp = int(time.time())
    async def one(o):
        return await client.execute_workflow(
            OrderWorkflow.run, o,
            id=f"order-{o['order_id']}-{stamp}",   # уникальный id на прогон
            task_queue="orders")
    results = await asyncio.gather(*(one(o) for o in orders), return_exceptions=True)
    failed = [r for r in results if isinstance(r, BaseException)]
    for r in results: print(r)
    return 1 if failed else 0

sys.exit(asyncio.run(main()))
```

## Отладка

- Web-UI http://localhost:8233 — история каждого workflow: какая activity
  упала, с каким сообщением, сколько было ретраев.
- `make state` — что моки думают о каждом заказе; `make ledger ORDER=ORD-1001` —
  журнал вызовов конкретного заказа.
- Отчёт чекера в конце `make verify` называет заказ и конкретную претензию.
- Изменил код — просто перезапусти `make verify` (worker стартует заново из run.sh).

## Чеклист перед verify

- [ ] Каждый заказ — отдельный workflow; запускаются конкурентно (gather в starter).
- [ ] Все HTTP-вызовы в activities; в workflows.py нет httpx/uuid/time.
- [ ] Ретраи — RetryPolicy; Business402/409 в non_retryable_error_types.
- [ ] Idempotency-Key создаётся в workflow один раз (workflow.uuid4()).
- [ ] Обе компенсации при провале доставки: refund И release.
- [ ] Уведомление — последним шагом при любом исходе.
- [ ] run.sh убивает worker по завершении и выходит с кодом 0.
