from datetime import timedelta
from temporalio import workflow
from temporalio.common import RetryPolicy
from temporalio.exceptions import ActivityError

with workflow.unsafe.imports_passed_through():
    from activities import (
        reserve_inventory,
        release_inventory,
        charge_payment,
        refund_payment,
        create_shipment,
        get_shipment_status,
        notify,
    )

RETRY = RetryPolicy(
    initial_interval=timedelta(seconds=0.5),
    backoff_coefficient=2.0,
    maximum_interval=timedelta(seconds=4),
    maximum_attempts=5,
    non_retryable_error_types=[
        "Business400", "Business402", "Business404", "Business409", "Business422",
    ],
)

OPTS = {"start_to_close_timeout": timedelta(seconds=10), "retry_policy": RETRY}


def business_type(err: ActivityError) -> str:
    cause = getattr(err, "cause", None)
    t = getattr(cause, "type", None) or ""
    return t if t.startswith("Business") else ""


@workflow.defn
class OrderWorkflow:
    @workflow.run
    async def run(self, order: dict) -> str:
        oid = order["order_id"]
        status = "completed"
        reason = None

        # Step 1: Reserve inventory
        try:
            await workflow.execute_activity(
                reserve_inventory, args=[oid, order["items"]], **OPTS
            )
        except ActivityError as e:
            if business_type(e) == "Business409":
                status = "cancelled"
                reason = "out_of_stock"
                await workflow.execute_activity(notify, args=[oid, status, reason], **OPTS)
                return f"{oid}:cancelled:out_of_stock"
            raise

        # Step 2: Charge payment
        key = f"pay-{oid}-{workflow.uuid4().hex[:8]}"
        try:
            await workflow.execute_activity(
                charge_payment, args=[oid, order["amount"], key], **OPTS
            )
        except ActivityError as e:
            if business_type(e) == "Business402":
                await workflow.execute_activity(release_inventory, oid, **OPTS)
                status = "cancelled"
                reason = "payment_declined"
                await workflow.execute_activity(notify, args=[oid, status, reason], **OPTS)
                return f"{oid}:cancelled:payment_declined"
            raise

        # Step 3: Create shipment
        shipment = await workflow.execute_activity(
            create_shipment, oid, **OPTS
        )
        shipment_id = shipment["shipment_id"]

        # Step 4: Poll shipment status
        current = "preparing"
        while current not in ("delivered", "failed"):
            await workflow.sleep(1)
            result = await workflow.execute_activity(
                get_shipment_status, shipment_id, **OPTS
            )
            current = result["status"]

        if current == "failed":
            # Compensations: refund and release in any order
            await workflow.execute_activity(refund_payment, oid, **OPTS)
            await workflow.execute_activity(release_inventory, oid, **OPTS)
            status = "cancelled"
            reason = "shipping_failed"
        else:
            status = "completed"
            reason = None

        # Step 6: Final notification
        await workflow.execute_activity(notify, args=[oid, status, reason], **OPTS)
        return f"{oid}:{status}:{reason or ''}"
