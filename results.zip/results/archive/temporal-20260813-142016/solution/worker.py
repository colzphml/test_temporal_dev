import asyncio
import os
from temporalio.client import Client
from temporalio.worker import Worker
import activities
from workflows import OrderWorkflow


async def main():
    client = await Client.connect(os.environ.get("TEMPORAL_ADDRESS", "localhost:7233"))
    worker = Worker(
        client,
        task_queue="orders",
        workflows=[OrderWorkflow],
        activities=[
            activities.reserve_inventory,
            activities.release_inventory,
            activities.charge_payment,
            activities.refund_payment,
            activities.create_shipment,
            activities.get_shipment_status,
            activities.notify,
        ],
    )
    print("worker started")
    await worker.run()


asyncio.run(main())
