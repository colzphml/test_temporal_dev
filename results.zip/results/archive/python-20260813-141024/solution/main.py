import asyncio
import uuid
import os

import httpx

BASE = os.environ.get("MOCKS_URL", "http://localhost:8100")


class BusinessError(Exception):
    def __init__(self, status_code: int, payload: dict):
        self.status_code = status_code
        self.payload = payload


async def call(client: httpx.AsyncClient, method: str, path: str, json=None, headers=None) -> dict:
    delay = 0.5
    for attempt in range(1, 6):
        try:
            r = await client.request(method, BASE + path, json=json, headers=headers)
            if r.status_code < 400:
                return r.json()
            if r.status_code in (400, 402, 404, 409, 422):
                raise BusinessError(r.status_code, r.json())
        except httpx.TransportError:
            pass
        if attempt == 5:
            raise RuntimeError(f"{method} {path}: retries exhausted after 5 attempts")
        await asyncio.sleep(delay)
        delay = min(delay * 2, 4)


async def process_order(client: httpx.AsyncClient, order: dict):
    oid = order["order_id"]
    pay_key = f"pay-{oid}-{uuid.uuid4().hex[:8]}"

    print(f"[{oid}] processing started")

    # Step 1: Reserve inventory
    try:
        await call(client, "POST", "/api/inventory/reserve",
                   json={"order_id": oid, "items": order["items"]})
        print(f"[{oid}] inventory reserved")
    except BusinessError as e:
        if e.status_code == 409:  # out_of_stock
            print(f"[{oid}] out of stock, cancelling")
            await call(client, "POST", "/api/notifications/notify",
                       json={"order_id": oid, "status": "cancelled", "reason": "out_of_stock"})
            print(f"[{oid}] notified (cancelled: out_of_stock)")
            return
        raise

    # Step 2: Charge payment
    try:
        await call(client, "POST", "/api/payments/charge",
                   json={"order_id": oid, "amount": order["amount"]},
                   headers={"Idempotency-Key": pay_key})
        print(f"[{oid}] payment charged")
    except BusinessError as e:
        if e.status_code == 402:  # card_declined
            print(f"[{oid}] card declined, compensating")
            await call(client, "POST", "/api/inventory/release",
                       json={"order_id": oid})
            await call(client, "POST", "/api/notifications/notify",
                       json={"order_id": oid, "status": "cancelled", "reason": "payment_declined"})
            print(f"[{oid}] notified (cancelled: payment_declined)")
            return
        raise

    # Step 3: Create shipment
    result = await call(client, "POST", "/api/shipping/shipments",
                        json={"order_id": oid})
    sid = result["shipment_id"]
    print(f"[{oid}] shipment created: {sid}")

    # Step 4: Poll for delivery
    while True:
        shipment = await call(client, "GET", f"/api/shipping/shipments/{sid}")
        status = shipment["status"]
        if status == "delivered":
            print(f"[{oid}] delivered")
            await call(client, "POST", "/api/notifications/notify",
                       json={"order_id": oid, "status": "completed", "reason": None})
            print(f"[{oid}] notified (completed)")
            return
        if status == "failed":
            print(f"[{oid}] shipping failed, compensating")
            # Compensate: refund + release (order doesn't matter between them)
            await asyncio.gather(
                call(client, "POST", "/api/payments/refund", json={"order_id": oid}),
                call(client, "POST", "/api/inventory/release", json={"order_id": oid}),
            )
            await call(client, "POST", "/api/notifications/notify",
                       json={"order_id": oid, "status": "cancelled", "reason": "shipping_failed"})
            print(f"[{oid}] notified (cancelled: shipping_failed)")
            return
        await asyncio.sleep(1)


async def main():
    async with httpx.AsyncClient(timeout=30, trust_env=False) as client:
        r = await client.get(f"{BASE}/api/orders")
        orders = r.json()
        print(f"Loaded {len(orders)} orders")
        await asyncio.gather(*(process_order(client, o) for o in orders))
    print("All orders processed")


if __name__ == "__main__":
    asyncio.run(main())
