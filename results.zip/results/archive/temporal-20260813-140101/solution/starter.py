import asyncio
import os
import sys
import time

import httpx
from temporalio.client import Client

from workflows import OrderWorkflow


async def main():
    base = os.environ.get("MOCKS_URL", "http://localhost:8100")
    async with httpx.AsyncClient(timeout=10, trust_env=False) as c:
        orders = (await c.get(base + "/api/orders")).json()

    client = await Client.connect(
        os.environ.get("TEMPORAL_ADDRESS", "localhost:7233")
    )
    stamp = int(time.time())

    async def one(o):
        return await client.execute_workflow(
            OrderWorkflow.run,
            o,
            id=f"order-{o['order_id']}-{stamp}",
            task_queue="orders",
        )

    results = await asyncio.gather(*(one(o) for o in orders), return_exceptions=True)
    failed = [r for r in results if isinstance(r, BaseException)]
    for r in results:
        print(r)
    return 1 if failed else 0


sys.exit(asyncio.run(main()))
