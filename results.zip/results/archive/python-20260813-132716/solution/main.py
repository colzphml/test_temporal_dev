import asyncio
import os
import uuid

import httpx

BASE = os.environ["MOCKS_URL"]


class BusinessError(Exception):
    def __init__(self, status_code, payload):
        self.status_code = status_code
        self.payload = payload


async def call(client, method, path, json=None, headers=None):
    delay = 0.5
    for attempt in range(1, 6):
        try:
            r = await client.request(
                method, BASE + path, json=json, headers=headers
            )
            if r.status_code < 400:
                return r.json() if r.content else {}
            if r.status_code in (400, 402, 404, 409, 422):
                raise BusinessError(r.status_code, r.json())
        except httpx.TransportError:
            pass
        if attempt == 5:
            raise RuntimeError(f"{method} {path}: retries exhausted")
        await asyncio.sleep(delay)
        delay = min(delay * 2, 4)


async def notify(client, order_id, status, reason=None):
    await call(
        client,
        "POST",
        "/api/notifications/notify",
        json={"order_id": order_id, "status": status, "reason": reason},
    )


async def process_order(client, order):
    oid = order["order_id"]
    pay_key = f"pay-{oid}-{uuid.uuid4().hex[:8]}"

    # Step 1: reserve inventory
    try:
        await call(
            client,
            "POST",
            "/api/inventory/reserve",
            json={"order_id": oid, "items": order["items"]},
        )
    except BusinessError as e:
        if e.status_code == 409 and e.payload.get("error") == "out_of_stock":
            print(f"{oid}: out of stock, cancelling")
            await notify(client, oid, "cancelled", "out_of_stock")
            return
        raise

    # Step 2: charge payment
    try:
        await call(
            client,
            "POST",
            "/api/payments/charge",
            json={"order_id": oid, "amount": order["amount"]},
            headers={"Idempotency-Key": pay_key},
        )
    except BusinessError as e:
        if e.status_code == 402 and e.payload.get("error") == "card_declined":
            print(f"{oid}: card declined, releasing reserve")
            await call(
                client,
                "POST",
                "/api/inventory/release",
                json={"order_id": oid},
            )
            await notify(client, oid, "cancelled", "payment_declined")
            return
        raise

    # Step 3: create shipment
    ship_resp = await call(
        client,
        "POST",
        "/api/shipping/shipments",
        json={"order_id": oid},
    )
    sid = ship_resp["shipment_id"]

    # Step 4: poll for delivery
    while True:
        ship_status = (
            await call(
                client,
                "GET",
                f"/api/shipping/shipments/{sid}",
            )
        )["status"]
        if ship_status == "delivered":
            print(f"{oid}: delivered")
            await notify(client, oid, "completed")
            return
        if ship_status == "failed":
            print(f"{oid}: shipping failed, compensating")
            # refund and release in parallel
            await asyncio.gather(
                call(
                    client,
                    "POST",
                    "/api/payments/refund",
                    json={"order_id": oid},
                ),
                call(
                    client,
                    "POST",
                    "/api/inventory/release",
                    json={"order_id": oid},
                ),
            )
            await notify(client, oid, "cancelled", "shipping_failed")
            return
        await asyncio.sleep(1)


async def main():
    async with httpx.AsyncClient(timeout=10, trust_env=False) as client:
        r = await client.get(f"{BASE}/api/orders")
        orders = r.json()
        print(f"Processing {len(orders)} orders")
        await asyncio.gather(*(process_order(client, o) for o in orders))
        print("All orders processed")


asyncio.run(main())
