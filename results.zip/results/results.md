# Результаты эксперимента

| вариант | модель | старт | длительность | verify всего | неудачных |
|---|---|---|---|---|---|
| python | copilot-code-large | 2026-08-13T13:15:59+03:00 | 3:00 | 3 | 0 |
| python | copilot-code-large | 2026-08-13T14:01:38+03:00 | 3:11 | 1 | 0 |
| temporal | copilot-code-large | 2026-08-13T13:28:04+03:00 | 3:15 | 2 | 0 |
| temporal | copilot-code-large | 2026-08-13T13:55:17+03:00 | 4:49 | 1 | 0 |
| python | copilot-code-large | 2026-08-13T14:07:46+03:00 | 1:29 | 1 | 0 |
| temporal | copilot-code-large | 2026-08-13T14:10:57+03:00 | 8:14 | 2 | 1 |

Токены/стоимость сессии допиши вручную (команда /cost в Claude Code).
